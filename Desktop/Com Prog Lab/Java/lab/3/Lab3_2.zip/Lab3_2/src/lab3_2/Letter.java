/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author usci
 */
public class Letter {
    private String allText,a1,a2,fin;

    public Letter(String b1 ,String b2){
        a1=b1;
        a2=b2;
        allText="";
    }
    public void addLine(String text){
      
        allText = allText +"\n"+text;
    }
    public String getText(){
        fin = "Dear "+a1+"\n"+allText+"\n\n"+"Sincerely,"+"\n\n"+a2;
        return fin;
    }
    
}
