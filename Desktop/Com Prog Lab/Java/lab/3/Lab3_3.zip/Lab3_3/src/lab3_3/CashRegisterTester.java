/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author usci
 */
public class CashRegisterTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CashRegister crg = new CashRegister(7);
        crg.recordPurchase(50);
        crg.recordPurchase(10);
        crg.recordTaxablePurchase(20);
        crg.enterPayment(100);
        System.out.printf("%.1f\n",crg.giveChange());
    }
    
}
