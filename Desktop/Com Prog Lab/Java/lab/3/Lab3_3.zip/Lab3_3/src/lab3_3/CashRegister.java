/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author usci
 */
public class CashRegister {
    public double input,total,fee ;
    public CashRegister(double amt){
        fee = amt;
    }
    public void recordPurchase(double amount){
        total += amount ;
    }
    public void recordTaxablePurchase(double amt){
        total = total + amt*(100+fee)/100;
    }
    public double getTotalTax(){
        double tax = total*fee/100;
        return tax;
    }
    public void enterPayment(double amount){
        input += amount ;
    }
    public double giveChange(){
        double change = input-total ;
        input = 0 ;
        total = 0 ;
        
        return change ;

    }
}
