/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;
import java.util.*;
/**
 *
 * @author usci
 */
public class TimeIntervalTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int start = scanner.nextInt();
        System.out.print("Enter stop time: ");
        int stop = scanner.nextInt();
        TimeInterval ti = new TimeInterval(start,stop);
        System.out.println(ti.getHours()+" hours "+ti.getMinutes()+" minutes");
    }
    
}
