/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

/**
 *
 * @author McIntosh
 */
public class SodaCan {
    private float h,r,volume,surfaceA;
    public SodaCan(float h,float d){
        this.h=h;
        r=d/2;
    }
    public float getVolume(){
        volume=(float)(Math.PI*r*r*h);
        return volume;
    }
    public float getSurfaceArea(){
        surfaceA=(float)(2*Math.PI*r*h+2*Math.PI*r*r);
        return surfaceA;
    }
}
