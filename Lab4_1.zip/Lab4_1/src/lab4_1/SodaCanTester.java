/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;
import java.util.*;
/**
 *
 * @author McIntosh
 */
public class SodaCanTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter height: ");
        float h = input.nextFloat();
        System.out.print("Enter diameter: ");
        float d = input.nextFloat();
        SodaCan soda = new SodaCan(h,d);
        System.out.printf("Volume: %.2f \nSurface Area: %.2f\n",soda.getVolume(),soda.getSurfaceArea());
    }
    
}
