/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_1;
import java.util.*;
import java.awt.*;
/**
 *
 * @author usci
 */
public class IntersectionPrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rmd = new Random();
            int x1 = rmd.nextInt(51);
            int x2 = rmd.nextInt(51);
            int y1 = rmd.nextInt(51);
            int y2 = rmd.nextInt(51);
            int w1 = rmd.nextInt(51);
            int w2 = rmd.nextInt(51);
            int h1 = rmd.nextInt(51);
            int h2 = rmd.nextInt(51);
        Rectangle r1 = new Rectangle(x1,y1,w1,h1);
        Rectangle r2 = new Rectangle(x2,y2,w2,h2);   
        System.out.println(r1);
        System.out.println(r2);
        Rectangle r3 = r1.intersection(r2);
        System.out.println ("Is the intersected rectangle empty?:" + r3.isEmpty());
    }
    
}
