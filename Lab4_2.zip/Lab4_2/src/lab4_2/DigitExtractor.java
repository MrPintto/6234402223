/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_2;

/**
 *
 * @author McIntosh
 */
public class DigitExtractor {
     int num,divide;
    public DigitExtractor(int anInteger) {
        divide=anInteger;
    }
    public int nextDigit(){
        num=divide%10;
        divide=divide/10;
        return num;
    }
}
