package lab8_2;
import java.util.ArrayList;
public class ChoiceQuestion extends Question{
    private ArrayList<String> choices = new ArrayList<String>();
    public ChoiceQuestion(String text){
        super(text);
    }
    public void addChoice(String choice,boolean correct){
        choices.add(choice);
        if(correct){
            super.setAnswer(choice);
        }
    }
    @Override
    public void display(){
        super.display();
        int n = 1;
        for(String i:choices){
            System.out.println(n+":"+i);
            n++;
        }
    }
    @Override
    public boolean checkAnswer(String response){
        return super.checkAnswer(choices.get(Integer.valueOf(response)-1));
    }
}
